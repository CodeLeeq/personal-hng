<?php
// variables

// smtp configuration
$smtp_host = 'smtp.mailtrap.io';
$smtp_username = 'c2b694593e436b';
$smtp_password = '0663aac7006359';
$smtp_port = 2525;

// stripe configuration var
$stripe_secret_key = "sk_test_2DXp9R4OyZp65DDaJRLVb2mF";


?>