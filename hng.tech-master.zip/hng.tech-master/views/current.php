<html>
	<?php include 'partials/header.php';?>
	<body class=" pi">
		<?php include 'partials/navbar.php';?>
		<div class="container">
			<header class="pi-header">
				<h1 class="h1">HNG 5.0 INTERNS</h1>
      </header>


      <div class="main-section">
     	<div class="container">
     		<div class="row">
     			<div class="col-md-3 col-sm-6 col-xs-12">
     				<div class="intern-block border-blue">
     					<img src="../app/img/about-talent.png" alt="">
     					  <h6>Mark Essien</h6>
                 <p>Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                 <ul class="list">
                 <li><a href="#" target="_blank"<i class="fab fa-twitter"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-github"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-medium"></i></a></li>
                 </ul>
     					    <a href="#" class="btn-view">view profile</a>
     				</div>
     			</div>
     			<div class="col-md-3 col-sm-6 col-xs-12">
           <div class="intern-block border-blue">
     					<img src="../app/img/about-talent.png" alt="">
     					  <h6>Mark Essien</h6>
                 <p>Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                 <ul class="list">
                 <li><a href="#" target="_blank"<i class="fab fa-twitter"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-github"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-medium"></i></a></li>
                 </ul>
     					    <a href="#" class="btn-view">view profile</a>
     				</div>
     			</div>
     			<div class="col-md-3 col-sm-6 col-xs-12">
           <div class="intern-block border-blue">
     					<img src="../app/img/about-talent.png" alt="">
     					  <h6>Mark Essien</h6>
                 <p>Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                 <ul class="list">
                 <li><a href="#" target="_blank"<i class="fab fa-twitter"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-github"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-medium"></i></a></li>
                 </ul>
     					    <a href="#" class="btn-view">view profile</a>
     				</div>
     			</div>
     			<div class="col-md-3 col-sm-6 col-xs-12">
           <div class="intern-block border-blue">
     					<img src="../app/img/about-talent.png" alt="">
     					  <h6>Mark Essien</h6>
                 <p>Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                 <ul class="list">
                 <li><a href="#" target="_blank"<i class="fab fa-twitter"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-github"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-medium"></i></a></li>
                 </ul>
     					    <a href="#" class="btn-view">view profile</a>
     				</div>
     			</div>
     		</div>
     		<div class="row">
     			<div class="col-md-3 col-sm-6 col-xs-12">
     			<div class="intern-block border-blue">
     					<img src="../app/img/about-talent.png" alt="">
     					  <h6>Mark Essien</h6>
                 <p>Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                 <ul class="list">
                 <li><a href="#" target="_blank"<i class="fab fa-twitter"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-github"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-medium"></i></a></li>
                 </ul>
     					    <a href="#" class="btn-view">view profile</a>
     				</div>
     			</div>
     			<div class="col-md-3 col-sm-6 col-xs-12">
           <div class="intern-block border-blue">
     					<img src="../app/img/about-talent.png" alt="">
     					  <h6>Mark Essien</h6>
                 <p>Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                 <ul class="list">
                 <li><a href="#" target="_blank"<i class="fab fa-twitter"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-github"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-medium"></i></a></li>
                 </ul>
     					    <a href="#" class="btn-view">view profile</a>
     				</div>
     			</div>
     			<div class="col-md-3 col-sm-6 col-xs-12">
           <div class="intern-block border-blue">
     					<img src="../app/img/about-talent.png" alt="">
     					  <h6>Mark Essien</h6>
                 <p>Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                 <ul class="list">
                 <li><a href="#" target="_blank"<i class="fab fa-twitter"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-github"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-medium"></i></a></li>
                 </ul>
     					    <a href="#" class="btn-view">view profile</a>
     				</div>
     			</div>
     			<div class="col-md-3 col-sm-6 col-xs-12">
           <div class="intern-block border-blue">
     					<img src="../app/img/about-talent.png" alt="">
     					  <h6>Mark Essien</h6>
                 <p>Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                 <ul class="list">
                 <li><a href="#" target="_blank"<i class="fab fa-twitter"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-github"></i></a></li>
                 <li><a href="#" target="_blank"<i class="fab fa-medium"></i></a></li>
                 </ul>
     					    <a href="#" class="btn-view">view profile</a>
     				</div>
     			</div>
     		</div>
     	</div>
     </div>

<nav aria-label="pag navigation example">
  <ul class="pag pagination justify-content-center">
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1">Previous</a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">4</a></li>
    <li class="page-item"><a class="page-link" href="#">5</a></li>
    <li class="page-item">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</nav>


					</div>
				</div>
			</section>


			</div>
		</section>
	</body>

	<?php include 'partials/footer.php';?>
</html>
